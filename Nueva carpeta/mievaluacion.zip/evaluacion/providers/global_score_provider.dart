// global_score_provider.dart - LensysApp Diagnostico Module

import 'package:flutter/material.dart';
import 'package:lensysapp/evaluacion/models/level_averages.dart';
import 'package:lensysapp/evaluacion/services/score_service.dart';

class TablaScoreProvider with ChangeNotifier {
  final EvaluacionService _service = EvaluacionService();

  Map<String, LevelAverages> _scoresPorDimension = {};

  Map<String, LevelAverages> get scoresPorDimension => _scoresPorDimension;

  Future<void> cargarPromediosPorDimension(String evaluacionId) async {
    try {
      _scoresPorDimension = await _service.obtenerPromediosPorDimension(evaluacionId);
      notifyListeners();
    } catch (e) {
      debugPrint('Error al cargar los promedios: $e');
    }
  }

  LevelAverages? obtenerPromedioDe(String dimensionId) {
    return _scoresPorDimension[dimensionId];
  }

  void limpiar() {
    _scoresPorDimension.clear();
    notifyListeners();
  }
}
