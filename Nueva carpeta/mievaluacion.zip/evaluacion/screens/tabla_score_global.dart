import 'package:flutter/material.dart';
import 'package:lensysapp/evaluacion/widgets/drawer_lensys.dart';
import 'package:lensysapp/services-home/text_size_provider.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../services/tabla_score_service.dart';

class TablaScoreGlobal extends StatelessWidget {
  const TablaScoreGlobal({super.key});

  Future<double> _cargarScoreGlobal() async {
    // Obtener la última empresa creada (ajusta según tu lógica de sesión)
    final supabase = Supabase.instance.client;
    final empresas = await supabase.from('empresas').select().order('created_at', ascending: false).limit(1);
    if (empresas is! List || empresas.isEmpty) throw Exception('No hay empresa seleccionada');
    final empresaId = empresas.first['id'] as String;
    // Usar el servicio real para obtener el último score global
    final scores = await ScoreGlobalService().obtenerScoresDeEmpresa(empresaId);
    if (scores.isEmpty) throw Exception('No hay score global registrado');
    return scores.first.score;
  }

  @override
  Widget build(BuildContext context) {
    final textSizeProvider = Provider.of<TextSizeProvider>(context);
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Resumen Global',
          style: TextStyle(
            fontFamily: 'Roboto',
            fontWeight: FontWeight.bold,
            fontSize: textSizeProvider.fontSize + 2,
            color: Colors.white,
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.menu, color: Colors.white),
            onPressed: () => Scaffold.of(context).openEndDrawer(),
          ),
        ],
      ),
      endDrawer: const DrawerLensys(),
      body: FutureBuilder<double>(
        future: _cargarScoreGlobal(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(child: Text('Error: \\${snapshot.error}'));
          }
          final score = snapshot.data ?? 0.0;
          return Center(
            child: Text(
              'Score Global: \\${score.toStringAsFixed(2)}%',
              style: TextStyle(
                fontFamily: 'Roboto',
                fontSize: textSizeProvider.fontSize,
                color: Colors.grey.shade700,
              ),
              textAlign: TextAlign.center,
            ),
          );
        },
      ),
    );
  }
}
