import 'package:supabase_flutter/supabase_flutter.dart';

class ScoreGlobal {
  final String empresaId;
  final double score;

  ScoreGlobal({
    required this.empresaId,
    required this.score,
  });
}

class ScoreGlobalService {
  final SupabaseClient _client = Supabase.instance.client;

  Future<List<ScoreGlobal>> obtenerScoresDeEmpresa(String empresaId) async {
    final response = await _client
        .from('calificaciones')
        .select('puntaje')
        .eq('empresa_id', empresaId);

    // ignore: unnecessary_type_check
    if (response is! List) {
      throw Exception('Respuesta inesperada del servidor');
    }

    final puntuaciones = response
        .map((row) => (row['puntaje'] ?? 0).toDouble())
        .whereType<double>()
        .toList();

    if (puntuaciones.isEmpty) return [];

    final promedio = puntuaciones.reduce((a, b) => a + b) / puntuaciones.length;

    return [
      ScoreGlobal(
        empresaId: empresaId,
        score: promedio * 20, // Escalar a porcentaje si tus puntajes van de 1 a 5
      ),
    ];
  }
}
