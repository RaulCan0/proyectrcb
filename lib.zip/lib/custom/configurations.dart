
//base de datos oficial
class Configurations {
  static String mSupabaseUrl = "https://hdwbaswbinbjbnziwsyu.supabase.co";

  static String mSupabaseKey =
      "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imhkd2Jhc3diaW5iamJueml3c3l1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDU1MDk5MTUsImV4cCI6MjA2MTA4NTkxNX0.Qa-Vk1ANQyGrpJCqj3Pnx-YNOvZFPppfP2dUSvGKoJI";
}
//prueba yerror 
/*class Configurations {
  static String mSupabaseUrl = "https://fetfblqudyvdupdtmqtr.supabase.co";
  static String mSupabaseKey =
    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZldGZibHF1ZHl2ZHVwZHRtcXRyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDQyNzA0OTAsImV4cCI6MjA1OTg0NjQ5MH0.F1qkPLjIGoqTIGeVTtJEgaQgGhicABMiW7U-0cSrNLA";

}*/
