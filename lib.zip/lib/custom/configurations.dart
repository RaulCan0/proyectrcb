
//base de datos oficial
class Configurations {
  static String mSupabaseUrl = "https://hdwbaswbinbjbnziwsyu.supabase.co";

  static String mSupabaseKey =
      "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imhkd2Jhc3diaW5iamJueml3c3l1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDU1MDk5MTUsImV4cCI6MjA2MTA4NTkxNX0.Qa-Vk1ANQyGrpJCqj3Pnx-YNOvZFPppfP2dUSvGKoJI";
}
//prueba y error 
/*class Configurations {
  static String mSupabaseUrl = "https://cnknelqjwskxqifmapkr.supabase.co";

  static String mSupabaseKey =
      "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNua25lbHFqd3NreHFpZm1hcGtyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDczMjQ2MjUsImV4cCI6MjA2MjkwMDYyNX0.i4T0vokH3kkJzal0ymZmqHPzCFlBmLdVxQ2DKlVFDdY";
}*/
