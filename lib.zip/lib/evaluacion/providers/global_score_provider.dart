// global_score_provider.dart - LensysApp Diagnostico Module

