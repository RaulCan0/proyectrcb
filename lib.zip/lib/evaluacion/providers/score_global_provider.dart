import 'package:flutter/material.dart';
import 'package:lensysapp/evaluacion/models/score_cargo.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/empresa.dart';
import '../services/tabla_score_service.dart';

class ScoreGlobalProvider with ChangeNotifier {
  final _client = Supabase.instance.client;

  ScoreGlobal? _scoreGlobal;
  ScoreGlobal? get scoreGlobal => _scoreGlobal;

  bool _isLoading = false;
  bool get isLoading => _isLoading;

  Stream<ScoreGlobal?>? _scoreStream;
  Stream<ScoreGlobal?>? get scoreStream => _scoreStream;

  /// Escucha el score global en tiempo real para una empresa y actualiza el estado.
  void listenScore(BuildContext context, Empresa empresa) {
    _isLoading = true;
    notifyListeners();
    try {
      _scoreStream = _client
          .from('calificacion')
          .stream(primaryKey: ['id'])
          .eq('empresa_id', empresa.id)
          .map((event) {
            // --- Lógica de cálculo ---
            final Map<int, List<Map<String, dynamic>>> porCargo = {1: [], 2: [], 3: []};
            for (final entry in event) {
              final cargo = entry['cargo'];
              if (porCargo.containsKey(cargo)) {
                porCargo[cargo]!.add(entry);
              }
            }
            List<ScoreCargo> scores = [];
            for (int cargo = 1; cargo <= 3; cargo++) {
              final califs = porCargo[cargo]!;
              int puntosObtenidos = 0;
              int puntosPosibles = 0;
              for (final calif in califs) {
                puntosObtenidos += (calif['puntaje'] ?? 0) as int;
                puntosPosibles += (calif['max_puntaje'] ?? 5) as int; // Asume 5 como máximo si no existe
              }
              double porcentaje = puntosPosibles > 0 ? (puntosObtenidos / puntosPosibles) * 100 : 0.0;
              scores.add(ScoreCargo(
                cargo: cargo,
                puntosObtenidos: puntosObtenidos,
                puntosPosibles: puntosPosibles,
                porcentaje: porcentaje,
              ));
            }
            return ScoreGlobal(
              empresaId: empresa.id,
              scorePorCargo: scores,
              shingoResults: null,
              totalShingo: 0,
            );
          });
    } catch (e) {
      // Manejo de error
    }
    _isLoading = false;
    notifyListeners();
  }
}
