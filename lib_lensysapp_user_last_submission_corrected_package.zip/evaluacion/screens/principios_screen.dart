// ignore_for_file: use_build_context_synchronously

import 'package:flutter/material.dart';
import 'package:lensysapp/custom/appcolors.dart';
import 'package:lensysapp/evaluacion/models/asociado.dart';
import 'package:lensysapp/evaluacion/models/calificacion.dart';
import 'package:lensysapp/evaluacion/models/empresa.dart';
import 'package:lensysapp/evaluacion/models/principio_json.dart';
import 'package:lensysapp/evaluacion/providers/asociados.dart';
import 'package:lensysapp/evaluacion/services/dimension_service.dart';
import 'package:lensysapp/evaluacion/services/json_service.dart';
import 'package:lensysapp/evaluacion/services/supabase_service.dart';
import 'package:provider/provider.dart';

import '../widgets/drawer_lensys.dart';
import 'comportamiento_evaluacion_screen.dart';

class PrincipiosScreen extends StatefulWidget {
  final Empresa empresa;
  final Asociado asociado;
  final String dimensionId;
  final String evaluacionId;

  const PrincipiosScreen({
    super.key,
    required this.empresa,
    required this.asociado,
    required this.dimensionId,
    required this.evaluacionId,
  });

  @override
  State<PrincipiosScreen> createState() => _PrincipiosScreenState();
}

class _PrincipiosScreenState extends State<PrincipiosScreen> {
  Map<String, List<PrincipioJson>> principiosUnicos = {};
  List<String> comportamientosEvaluados = [];
  Map<String, Calificacion> calificacionesExistentes = {};
  bool cargando = true;
  final SupabaseService _supabaseService = SupabaseService();

  @override
  void initState() {
    super.initState();
    cargarDatos();
  }

  Future<void> cargarDatos() async {
    setState(() => cargando = true);
    try {
      final datosJson = await JsonService.cargarJson('t${widget.dimensionId}.json');
      final todosLosPrincipios = datosJson.map((e) => PrincipioJson.fromJson(e)).toList();
      final principiosFiltrados = todosLosPrincipios
          .where((p) => p.cargo.toLowerCase().contains(widget.asociado.cargo.toLowerCase()))
          .toList();

      final agrupados = <String, List<PrincipioJson>>{};
      for (var p in principiosFiltrados) {
        agrupados.putIfAbsent(p.nombre.trim(), () => []).add(p);
      }
      agrupados.removeWhere((key, value) => value.isEmpty);

      final calificaciones = await _supabaseService.getCalificacionesPorAsociado(widget.asociado.id);
      final tempComportamientosEvaluados = <String>[];
      final tempCalificacionesExistentes = <String, Calificacion>{};
      for (var cal in calificaciones) {
        tempComportamientosEvaluados.add(cal.comportamiento);
        tempCalificacionesExistentes[cal.comportamiento] = cal;
      }

      final asociadoProvider = Provider.of<AsociadosProvider>(context, listen: false);
      agrupados.forEach((nombrePrincipio, lista) {
        final total = lista.length;
        final evaluados = lista.where((p) {
          final nombre = p.benchmarkComportamiento.split(":").first.trim();
          return tempComportamientosEvaluados.contains(nombre);
        }).length;
        asociadoProvider.actualizarProgreso(
          idAsociado: widget.asociado.id,
          idDimension: widget.dimensionId,
          totalComportamientos: total,
          comportamientosEvaluados: evaluados,
        );
      });

      setState(() {
        principiosUnicos = agrupados;
        comportamientosEvaluados = tempComportamientosEvaluados;
        calificacionesExistentes = tempCalificacionesExistentes;
        cargando = false;
      });
    } catch (e) {
      setState(() => cargando = false);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error al cargar datos: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      backgroundColor: isDarkMode ? Colors.black : Colors.white,
      appBar: AppBar(
        title: Center(
          child: Text(
            ' ${DimensionService.nombrePorId(widget.dimensionId)}',
            style: const TextStyle(color: Colors.white),
          ),
        ),
        backgroundColor: isDarkMode ? Colors.black : AppColors.primary,
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          Builder(
            builder: (context) => IconButton(
              icon: const Icon(Icons.menu, color: Colors.white),
              onPressed: () => Scaffold.of(context).openEndDrawer(),
            ),
          ),
        ],
      ),
      endDrawer: const DrawerLensys(),
      body: cargando
          ? const Center(child: CircularProgressIndicator())
          : principiosUnicos.isEmpty
              ? const Center(child: Text('No hay principios para este cargo'))
              : Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    children: [
                      Card(
                        elevation: 4,
                        margin: const EdgeInsets.symmetric(vertical: 16),
                        child: Padding(
                          padding: const EdgeInsets.all(16.0),
                          child: Center(
                            child: Text(
                              'EVALUANDO A: ${widget.asociado.nombre}\nCargo: ${widget.asociado.cargo.toUpperCase()}',
                              style: const TextStyle(
                                  fontSize: 15, fontWeight: FontWeight.bold),
                              textAlign: TextAlign.center,
                            ),
                          ),
                        ),
                      ),
                      Expanded(
                        child: ListView(
                          children: principiosUnicos.entries.map((entry) {
                            final total = entry.value.length;
                            final evaluados = entry.value.where((p) {
                              final nombre = p.benchmarkComportamiento.split(":").first.trim();
                              return comportamientosEvaluados.contains(nombre);
                            }).length;
                            final progreso = total == 0 ? 0.0 : evaluados / total;

                            return Container(
                              margin: const EdgeInsets.symmetric(vertical: 8.0),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(12),
                                color: Color.lerp(
                                  const Color(0xFFB8B3B3),
                                  const Color(0xFF9ADA9C),
                                  progreso,
                                ),
                                border: Border.all(color: Colors.black, width: 2),
                              ),
                              child: ExpansionTile(
                                title: Column(
                                  children: [
                                    Text(
                                      entry.key,
                                      textAlign: TextAlign.center,
                                      style: const TextStyle(
                                          fontSize: 18, fontWeight: FontWeight.bold),
                                    ),
                                    Text(
                                      '$evaluados de $total comportamientos evaluados',
                                      textAlign: TextAlign.center,
                                      style: const TextStyle(fontSize: 16),
                                    ),
                                  ],
                                ),
                                children: entry.value.map((principio) {
                                  final comportamientoNombre = principio.benchmarkComportamiento.split(":").first.trim();
                                  final calificacionActual = calificacionesExistentes[comportamientoNombre];

                                  return ListTile(
                                    title: Text(
                                      comportamientoNombre,
                                      style: TextStyle(
                                        color: comportamientosEvaluados.contains(comportamientoNombre)
                                            ? const Color.fromARGB(255, 79, 109, 80)
                                            : Colors.black,
                                        fontWeight: comportamientosEvaluados.contains(comportamientoNombre)
                                            ? FontWeight.bold
                                            : FontWeight.normal,
                                      ),
                                    ),
                                    subtitle: Text(
                                      principio.benchmarkComportamiento.split(":").last.trim(),
                                      textAlign: TextAlign.center,
                                      style: const TextStyle(color: Colors.black),
                                    ),
                                    trailing: const Icon(
                                      Icons.arrow_forward_ios,
                                      color: Colors.black,
                                    ),
                                    onTap: () async {
                                      final resultado = await Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                          builder: (_) => ComportamientoEvaluacionScreen(
                                            principio: principio,
                                            cargo: widget.asociado.cargo,
                                            evaluacionId: widget.evaluacionId,
                                            dimensionId: widget.dimensionId,
                                            empresaId: widget.empresa.id,
                                            asociadoId: widget.asociado.id,
                                            calificacionExistente: calificacionActual,
                                            dimension: '',
                                          ),
                                        ),
                                      );
                                      if (resultado != null) {
                                        await cargarDatos();
                                      }
                                    },
                                  );
                                }).toList(),
                              ),
                            );
                          }).toList(),
                        ),
                      ),
                    ],
                  ),
                ),
    );
  }
}
