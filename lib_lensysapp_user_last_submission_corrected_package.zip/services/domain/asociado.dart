
class Asociado {
  final String id;
  final String nombre;
  final String cargo;
  final int antiguedad;
  final String empresaId;
  final String? alias;

  Asociado({
    required this.id,
    required this.nombre,
    required this.cargo,
    required this.antiguedad,
    required this.empresaId,
    this.alias,
  });

  factory Asociado.fromMap(Map<String, dynamic> map) => Asociado(
    id: map['id'],
    nombre: map['nombre'],
    cargo: map['cargo'],
    antiguedad: map['antiguedad'],
    empresaId: map['empresa_id'],
    alias: map['alias'],
  );

  Map<String, dynamic> toMap() => {
    'id': id,
    'nombre': nombre,
    'cargo': cargo,
    'antiguedad': antiguedad,
    'empresa_id': empresaId,
    'alias': alias,
  };
}
