
class Calificacion {
  final String id;
  final String idAsociado;
  final String idEmpresa;
  final int? idDimension;
  final String comportamiento;
  final int? puntaje;
  final DateTime? fechaEvaluacion;
  final String? observaciones;
  final String? sistemas;
  final String? evidenciaUrl;

  Calificacion({
    required this.id,
    required this.idAsociado,
    required this.idEmpresa,
    this.idDimension,
    required this.comportamiento,
    this.puntaje,
    this.fechaEvaluacion,
    this.observaciones,
    this.sistemas,
    this.evidenciaUrl,
  });

  factory Calificacion.fromMap(Map<String, dynamic> map) => Calificacion(
    id: map['id'],
    idAsociado: map['id_asociado'],
    idEmpresa: map['id_empresa'],
    idDimension: map['id_dimension'],
    comportamiento: map['comportamiento'],
    puntaje: map['puntaje'],
    fechaEvaluacion: map['fecha_evaluacion'] != null ? DateTime.parse(map['fecha_evaluacion']) : null,
    observaciones: map['observaciones'],
    sistemas: map['sistemas'],
    evidenciaUrl: map['evidencia_url'],
  );

  Map<String, dynamic> toMap() => {
    'id': id,
    'id_asociado': idAsociado,
    'id_empresa': idEmpresa,
    'id_dimension': idDimension,
    'comportamiento': comportamiento,
    'puntaje': puntaje,
    'fecha_evaluacion': fechaEvaluacion?.toIso8601String(),
    'observaciones': observaciones,
    'sistemas': sistemas,
    'evidencia_url': evidenciaUrl,
  };
}
