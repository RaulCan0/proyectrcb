
class Empresa {
  final String id;
  final String nombre;
  final String tamano;
  final int empleadosTotal;
  final String unidades;
  final int areas;
  final String sector;

  Empresa({
    required this.id,
    required this.nombre,
    required this.tamano,
    required this.empleadosTotal,
    required this.unidades,
    required this.areas,
    required this.sector,
  });

  factory Empresa.fromMap(Map<String, dynamic> map) => Empresa(
    id: map['id'],
    nombre: map['nombre'],
    tamano: map['tamano'],
    empleadosTotal: map['empleados_total'],
    unidades: map['unidades'],
    areas: map['areas'],
    sector: map['sector'],
  );

  Map<String, dynamic> toMap() => {
    'id': id,
    'nombre': nombre,
    'tamano': tamano,
    'empleados_total': empleadosTotal,
    'unidades': unidades,
    'areas': areas,
    'sector': sector,
  };
}
