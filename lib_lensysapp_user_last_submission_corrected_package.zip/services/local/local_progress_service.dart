
import 'package:flutter/material.dart';

class LocalProgressService with ChangeNotifier {
  final Map<String, int> _progresoPorAsociado = {};

  int getProgreso(String asociadoId) => _progresoPorAsociado[asociadoId] ?? 0;

  void actualizarProgreso(String asociadoId, int valor) {
    _progresoPorAsociado[asociadoId] = valor;
    notifyListeners();
  }
}
