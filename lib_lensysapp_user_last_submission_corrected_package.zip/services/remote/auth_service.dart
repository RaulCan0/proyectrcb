
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:flutter/material.dart';

class AuthService {
  final SupabaseClient _client = Supabase.instance.client;

  bool get isAuthenticated => _client.auth.currentSession != null;

  Future<Map<String, dynamic>> login(String email, String password) async {
    try {
      await _client.auth.signInWithPassword(email: email, password: password);
      return {'success': true};
    } on AuthException catch (e) {
      return {'success': false, 'message': e.message};
    } catch (e) {
      return {'success': false, 'message': e.toString()};
    }
  }

  Future<void> signOut() async => await _client.auth.signOut();
}
