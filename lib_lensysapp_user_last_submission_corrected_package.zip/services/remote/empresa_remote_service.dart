
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:flutter/material.dart';
import '../../domain/empresa.dart';

class EmpresaRemoteService {
  final _client = Supabase.instance.client;

  Future<List<Empresa>> getEmpresas() async {
    try {
      final res = await _client.from('empresas').select();
      return (res as List).map((e) => Empresa.fromMap(e)).toList();
    } catch (e) {
      debugPrint('Error al obtener empresas: $e');
      return [];
    }
  }
}
