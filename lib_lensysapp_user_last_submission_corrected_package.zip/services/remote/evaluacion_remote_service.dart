
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:flutter/material.dart';
import '../../domain/evaluacion.dart';

class EvaluacionRemoteService {
  final _client = Supabase.instance.client;

  Future<void> addEvaluacion(Evaluacion evaluacion) async {
    await _client.from('evaluacion').insert(evaluacion.toMap());
  }

  Future<List<Evaluacion>> getEvaluaciones(String empresaId) async {
    try {
      final res = await _client.from('evaluacion').select().eq('empresa_id', empresaId);
      return (res as List).map((e) => Evaluacion.fromMap(e)).toList();
    } catch (e) {
      debugPrint('Error obteniendo evaluaciones: $e');
      return [];
    }
  }
}
